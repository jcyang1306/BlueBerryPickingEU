#include <iostream>
#include <thread>
#include "../include/eu_planet.h"

int main()
{
    if (PLANET_SUCCESS != planet_initDLL(planet_DeviceType_USBCAN2, 0, 0, planet_Baudrate_1000))
    {
        std::cout << "test open1 failed!" << std::endl;
        planet_freeDLL(0);
        return -1;
    }
    if (PLANET_SUCCESS != planet_initDLL(planet_DeviceType_USBCAN2, 1, 0, planet_Baudrate_1000))
    {
        std::cout << "test open2 failed!" << std::endl;
        planet_freeDLL(1);
        return -1;
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));

    planet_freeDLL(0);
    planet_freeDLL(1);
    return 0;
}