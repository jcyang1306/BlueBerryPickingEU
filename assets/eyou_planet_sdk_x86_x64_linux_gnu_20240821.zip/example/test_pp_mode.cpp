#include <iostream>
#include <thread>
#include <csignal>
#include "../include/eu_planet.h"

int devIndex = 0;
int channel = 0;
int id = 1;

void exit_handler()
{
    planet_freeDLL(devIndex);
}

void signal_handler(int signal) 
{
    exit_handler();
    exit(1);
}

// 轮廓位置模式控制示例程序
int main()
{
    atexit(exit_handler);
    signal(SIGINT, signal_handler);
    signal(SIGSEGV, signal_handler);
    if (PLANET_SUCCESS != planet_initDLL(planet_DeviceType_Canable, devIndex, channel, planet_Baudrate_1000))
    {
        std::cout << "test open failed!" << std::endl;
        return -1;
    }
    bool heartbeat = false;
    if (PLANET_SUCCESS != planet_getHeartbeat(devIndex, id, &heartbeat))
    {
        std::cout << "get hearbeat failed!(id not exists!)" << std::endl;
        return -1;
    }
    std::cout << "heart beat:" << heartbeat << std::endl;
    if (PLANET_SUCCESS != planet_setEnabled(devIndex, id, true))
    {
        std::cout << "set enabled failed!" << std::endl;
        return -1;
    }
    //    轮廓位置模式
    planet_setMode(devIndex, id, 1);
    planet_setTargetVelocity(devIndex, id, 10);
    planet_setTargetCurrent(devIndex, id, 2000);
    planet_setTargetAcceleration(devIndex, id, 1000);
    planet_setTargetDeceleration(devIndex, id, 1000);
    float pos = 180;
    while (1)
    {
        std::cout << "moving to " << pos << " degrees" << std::endl;
        planet_setTargetPosition(devIndex, id, pos);
        180 == pos ? pos = 0 : pos = 180;
        std::this_thread::sleep_for(std::chrono::seconds(4));
    }
    return 0;
}