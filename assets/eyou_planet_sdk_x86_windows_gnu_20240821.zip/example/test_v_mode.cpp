#include <iostream>
#include <thread>
#include <csignal>
#include "../include/eu_planet.h"

int devIndex = 0;
int channel = 0;
int id = 1;

void exit_handler()
{
    planet_freeDLL(devIndex);
}

void signal_handler(int signal)
{
    exit_handler();
    exit(1);
}

// 速度模式控制示例程序
int main()
{
    atexit(exit_handler);
    signal(SIGINT, signal_handler);
    signal(SIGSEGV, signal_handler);
    if (PLANET_SUCCESS != planet_initDLL(planet_DeviceType_Canable, devIndex, channel, planet_Baudrate_1000))
    {
        std::cout << "test open failed!" << std::endl;
        return -1;
    }
    bool heartbeat = false;
    if (PLANET_SUCCESS != planet_getHeartbeat(devIndex, id, &heartbeat, 300000))
    {
        std::cout << "get hearbeat failed!(id not exists!)" << std::endl;
        return -1;
    }
    std::cout << "heart beat:" << heartbeat << std::endl;
    if (PLANET_SUCCESS != planet_setEnabled(devIndex, id, true))
    {
        std::cout << "set enabled failed!" << std::endl;
        return -1;
    }
    planet_setMode(devIndex, id, 3);
    planet_setTargetCurrent(devIndex, id, 2000);
    planet_setTargetVelocity(devIndex, id, 10);
    return 0;
}