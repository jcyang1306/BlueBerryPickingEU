#include <iostream>
#include <thread>
#include <csignal>
#include "../include/eu_planet.h"

int devIndex = 0;
int channel = 0;
int id = 1;

void sendCallback(int id, const unsigned char *data, int size)
{
}

void receiveCallback(int id, const unsigned char *data, int size)
{
}

void exit_handler()
{
    planet_freeDLL(devIndex);
}

void signal_handler(int signal) 
{
    exit_handler();
    exit(1);
}

int main()
{
    atexit(exit_handler);
    signal(SIGINT, signal_handler);
    signal(SIGSEGV, signal_handler);
    if (PLANET_SUCCESS != planet_initDLL(planet_DeviceType_Canable, devIndex, channel, planet_Baudrate_1000))
    {
        std::cout << "test open failed!" << std::endl;
        planet_freeDLL(devIndex);
        return -1;
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    planet_setSendCallFunction(sendCallback);
    planet_setReceiveCallFunction(receiveCallback);

    bool heartbeat = false;
    if (PLANET_SUCCESS != planet_getHeartbeat(devIndex, id, &heartbeat, 3000))
    {
        std::cout << "[error]get hearbeat failed!" << std::endl;
        return -1;
    }
    std::cout << "heart beat:" << heartbeat << std::endl;

    unsigned serialNum = 0;
    if (PLANET_SUCCESS != planet_getSerialNumber(devIndex, id, &serialNum))
    {
        std::cout << "[error]get serial number failed!" << std::endl;
        return -1;
    }
    std::cout << "serial number:" << serialNum << std::endl;

    unsigned hdVersion = 0;
    if (PLANET_SUCCESS != planet_getHardwareVersion(devIndex, id, &hdVersion))
    {
        std::cout << "[error]get hardware version failed!" << std::endl;
        return -1;
    }
    std::cout << "hard version:" << hdVersion << std::endl;

    unsigned fmVersion = 0;
    if (PLANET_SUCCESS != planet_getFirmwareVersion(devIndex, id, &fmVersion))
    {
        std::cout << "[error]get firmware version failed!" << std::endl;
        return -1;
    }
    std::cout << "firmware version:" << fmVersion << std::endl;

    float current = 0;
    if (PLANET_SUCCESS != planet_getCurrent(devIndex, id, &current))
    {
        std::cout << "[error]get current failed!" << std::endl;
        return -1;
    }
    std::cout << "current torque:" << current << std::endl;

    float velocity = 0;
    if (PLANET_SUCCESS != planet_getVelocity(devIndex, id, &velocity))
    {
        std::cout << "[error]get velocity failed!" << std::endl;
        return -1;
    }
    std::cout << "current velocity:" << velocity << std::endl;

    float position = 0;
    if (PLANET_SUCCESS != planet_getPosition(devIndex, id, &position))
    {
        std::cout << "[error]get position failed!" << std::endl;
        return -1;
    }
    std::cout << "current position:" << position << std::endl;

    float targetCurrent = 0;
    if (PLANET_SUCCESS != planet_getTargetCurrent(devIndex, id, &targetCurrent))
    {
        std::cout << "[error]get target current failed!" << std::endl;
        return -1;
    }
    std::cout << "target current:" << targetCurrent << std::endl;

    float targetVelocity = 0;
    if (PLANET_SUCCESS != planet_getTargetVelocity(devIndex, id, &targetVelocity))
    {
        std::cout << "[error]get target velocity failed!" << std::endl;
        return -1;
    }
    std::cout << "target velocity:" << targetVelocity << std::endl;

    float ratio = 0;
    if (PLANET_SUCCESS != planet_getElectronicGearRatio(devIndex, id, &ratio))
    {
        std::cout << "[error]get electronic gear ratio failed!" << std::endl;
        return -1;
    }
    std::cout << "electronic gear ratio:" << ratio << std::endl;

    bool enable = false;
    if (PLANET_SUCCESS != planet_getEnabled(devIndex, id, &enable))
    {
        std::cout << "[error]get enabled failed!" << std::endl;
        return -1;
    }
    std::cout << "current enable state:" << enable << std::endl;

    int mode = 0;
    if (PLANET_SUCCESS != planet_getMode(devIndex, id, &mode))
    {
        std::cout << "[error]get mode failed!" << std::endl;
        return -1;
    }
    std::cout << "current mode:" << mode << std::endl;
    return 0;
}